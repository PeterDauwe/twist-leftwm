#!/bin/bash
#
##################################################################################################################
# Written to be used on 64 bits computers
# Author 	: 	Erik Dubois
# Website 	: 	http://www.erikdubois.be
##################################################################################################################
##################################################################################################################
#
#   DO NOT JUST RUN THIS. EXAMINE AND JUDGE. RUN AT YOUR OWN RISK.
#
##################################################################################################################

echo "This updates the existing githubs"
echo "Fill the array with the original folders first"

# use ls -d */ > list to get the list of the created githubs and copy/paste in

directories=(
arcolinux-alacritty/
arcolinux-apps/
arcolinux-app-template/
arcolinux-arc-themes/
arcolinux-betterlockscreen/
arcolinux-bin/
arcolinuxb-installer/
arcolinux-calamares-tool/
arcolinux-calamares-tool-dev/
arcolinux-common/
arcolinux-conky-collection/
arcolinux-conky-collection-plasma/
arcolinux-cron/
arcolinux-docs/
arcolinuxd-system-config/
arcolinux-dwm-slstatus/
arcolinux-dwm-st/
arcolinux-faces/
arcolinux-fonts/
arcolinux-geany/
arcolinux-glava-config/
arcolinux-gtk3-sardi-arc/
arcolinux-gtk3-surfn-arc/
arcolinux-gtk3-surfn-arc-breeze/
arcolinux-gtk3-surfn-plasma-dark/
arcolinux-guake-autostart/
arcolinux-kvantum/
arcolinux-kvantum-lxqt/
arcolinux-kvantum-plasma/
arcolinux-kvantum-theme-arc/
arcolinux-local-applications/
arcolinux-local-applications-plasma-hide/
arcolinux-local-xfce4/
arcolinux-logo/
arcolinux-logout/
arcolinux-logout-themes/
arcolinux-lxqt-applications-add/
arcolinux-lxqt-applications-hide/
arcolinux-mint-y-icons/
arcolinux-mirrorlist/
arcolinux-mirrorlist-spinoff/
arcolinux-neofetch/
arcolinux-nitrogen/
arcolinux-obmenu-generator/
arcolinux-obmenu-generator-minimal/
arcolinux-obmenu-generator-xtended/
arcolinux-openbox-themes/
arcolinux-paleofetch/
arcolinux-paru/
arcolinux-pipemenus/
arcolinux-plank/
arcolinux-plank-themes/
arcolinux-plasma-kservices/
arcolinux-polybar/
arcolinux-qt5/
arcolinux-qt5-plasma/
arcolinux-reflector-simple/
arcolinux-rofi/
arcolinux-rofi-themes/
arcolinux-root/
arcolinux-sddm-chili/
arcolinux-sddm-fralonra/
arcolinux-sddm-futuristic/
arcolinux-sddm-materia/
arcolinux-sddm-plasma-archpaint/
arcolinux-sddm-plasma-breeze/
arcolinux-sddm-redrock/
arcolinux-sddm-slice/
arcolinux-sddm-sugar-candy/
arcolinux-sddm-urbanlifestyle/
arcolinux-spices/
arcolinux-system-config/
arcolinux-system-config-dev/
arcolinux-systemd-services/
arcolinux-system-installation/
arcolinux-tellme/
arcolinux-termite-themes/
arcolinux-tint2/
arcolinux-tint2-themes/
arcolinux-tweak-tool/
arcolinux-tweak-tool-dev/
arcolinux-variety/
arcolinux-variety-autostart/
arcolinux-volumeicon/
arcolinux-wallpapers/
arcolinux-wallpapers-lxqt-dual/
arcolinux-welcome-app/
arcolinux-welcome-app-deepin/
arcolinux-welcome-app-dev/
arcolinux-xfce-panel-profiles/
arcolinux-xlunch/
arcolinux-xmobar/
arcolinux-zsh/
)

count=0

for name in "${directories[@]}"; do
	count=$[count+1]
	tput setaf 1;echo "Github "$count;tput sgr0;
	# if there is no folder then make one
	git clone https://github.com/arcolinux/$name
	echo "#################################################"
	echo "################  "$(basename `pwd`)" done"
	echo "#################################################"
done
