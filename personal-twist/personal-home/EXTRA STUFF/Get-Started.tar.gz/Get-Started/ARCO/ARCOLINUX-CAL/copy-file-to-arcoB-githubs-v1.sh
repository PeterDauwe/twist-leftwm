#!/bin/bash
#
##################################################################################################################
# Written to be used on 64 bits computers
# Author 		: 	Erik Dubois
# Website 	: 	http://www.erikdubois.be
##################################################################################################################
##################################################################################################################
#
#   DO NOT JUST RUN THIS. EXAMINE AND JUDGE. RUN AT YOUR OWN RISK.
#
##################################################################################################################

source="/home/erik/ARCO/ARCOLINUX-CAL/"
#file="netinstall-communication.yaml"
file="netinstall-utilities.yaml"
source=$source$file
echo "Copying from here... "
echo $source
dirs=$(echo arcob*/)
for dir in $dirs
do
	cp -v $source $dir"calamares/modules/"
done
