#!/bin/bash
#
##################################################################################################################
# Written to be used on 64 bits computers
# Author 		: 	Erik Dubois
# Website 	: 	http://www.erikdubois.be
##################################################################################################################
##################################################################################################################
#
#   DO NOT JUST RUN THIS. EXAMINE AND JUDGE. RUN AT YOUR OWN RISK.
#
##################################################################################################################

# we start at ArcoLinuxB Xfce

source="/home/erik/ARCO/ARCOLINUX-CAL/"


directories=(
arcob-calamares-config-awesome/
arcob-calamares-config-bspwm/
arcob-calamares-config-budgie/
arcob-calamares-config-cinnamon/
arcob-calamares-config-cwm/
arcob-calamares-config-deepin/
arcob-calamares-config-dwm/
arcob-calamares-config-enlightenment/
arcob-calamares-config-fvwm3/
arcob-calamares-config-gnome/
arcob-calamares-config-herbstluftwm/
arcob-calamares-config-i3/
arcob-calamares-config-icewm/
arcob-calamares-config-jwm/
arcob-calamares-config-lxqt/
arcob-calamares-config-mate/
arcob-calamares-config-openbox/
arcob-calamares-config-plasma/
arcob-calamares-config-qtile/
arcob-calamares-config-spectrwm/
arcob-calamares-config-ukui/
arcob-calamares-config-xmonad/
arcob-calamares-config-xtended/
)

files=(
netinstall-applications.yaml
netinstall-arcolinuxdev.yaml
netinstall-arcolinux.yaml
netinstall-communication.yaml
netinstall-desktop.yaml
netinstall-development.yaml
netinstall-drivers.yaml
netinstall-filemanagers.yaml
netinstall-fonts.yaml
netinstall-gaming.yaml
netinstall-graphics.yaml
netinstall-internet.yaml
netinstall-kernel.yaml
netinstall-login.yaml
netinstall-multimedia.yaml
netinstall-office.yaml
netinstall-terminals.yaml
netinstall-theming.yaml
netinstall-usb.yaml
netinstall-utilities.yaml
)

count=0

for name in "${directories[@]}"; do
	count=$[count+1]
	echo $count " - " $name
	
	for file in "${files[@]}"; do

		sourceFile=$source"arcob-calamares-config-xfce/calamares/modules/"$file
		echo "      "$sourceFile
		targetFile=$source$name"calamares/modules/"$file
		echo "      "$targetFile
		cp $sourceFile $targetFile
	done
done

