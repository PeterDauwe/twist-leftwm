#!/bin/bash
#
##################################################################################################################
# Written to be used on 64 bits computers
# Author 		: 	Erik Dubois
# Website 	: 	http://www.erikdubois.be
##################################################################################################################
##################################################################################################################
#
#   DO NOT JUST RUN THIS. EXAMINE AND JUDGE. RUN AT YOUR OWN RISK.
#
##################################################################################################################
#what file to remove
remove="netinstall-drivers.yaml"
dirs=$(echo arcob*/)
for dir in $dirs
do
	rm  $dir"calamares/branding/arcolinuxnew/"$remove
done
